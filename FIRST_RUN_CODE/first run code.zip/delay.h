#ifndef DELAY_H
#define DELAY_H

void delay(unsigned int time);

#endif

