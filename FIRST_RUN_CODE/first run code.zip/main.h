#ifndef MAIN_H
#define MAIN_H

#include <xc.h>
#include "delay.h"
#include "eeprom.h"
#include "clcd.h"

#endif

